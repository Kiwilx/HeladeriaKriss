/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.puntoventahelados;
import com.mycompany.puntoventahelados.Menu.historialVenta;
import com.mycompany.puntoventahelados.Menu.ventaHelado;
import javax.swing.JFrame;

/**
 *
 * @author avero
 */
public class inicioMenu extends javax.swing.JFrame {

    private ventaHelado ventanaHelado;
    public inicioMenu() {
        initComponents();
        this.setExtendedState(inicioMenu.MAXIMIZED_BOTH);
        ventaMenu = new javax.swing.JMenu("Venta");

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuBar2 = new javax.swing.JMenuBar();
        jMenu3 = new javax.swing.JMenu();
        ventaMenu = new javax.swing.JMenu();
        ventMenuItem = new javax.swing.JMenuItem();
        ventHistorialMenuItem = new javax.swing.JMenuItem();
        config = new javax.swing.JMenu();
        usuariosMenuItem = new javax.swing.JMenuItem();
        salirMenuItem = new javax.swing.JMenu();
        jMenuItem3 = new javax.swing.JMenuItem();

        jMenuItem1.setText("jMenuItem1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jMenu3.setText("File");
        jMenuBar2.add(jMenu3);

        ventaMenu.setText("Venta");
        ventaMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ventaMenuActionPerformed(evt);
            }
        });

        ventMenuItem.setText("Vender Helado");
        ventMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ventMenuItemActionPerformed(evt);
            }
        });
        ventaMenu.add(ventMenuItem);

        ventHistorialMenuItem.setText("Historial");
        ventHistorialMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ventHistorialMenuItemActionPerformed(evt);
            }
        });
        ventaMenu.add(ventHistorialMenuItem);

        jMenuBar2.add(ventaMenu);

        config.setText("Configuración");

        usuariosMenuItem.setText("Usuarios");
        usuariosMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                usuariosMenuItemActionPerformed(evt);
            }
        });
        config.add(usuariosMenuItem);

        jMenuBar2.add(config);

        salirMenuItem.setText("Salir");

        jMenuItem3.setText("Cerrar Sesión");
        salirMenuItem.add(jMenuItem3);

        jMenuBar2.add(salirMenuItem);

        setJMenuBar(jMenuBar2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 710, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 473, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ventaMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ventaMenuActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_ventaMenuActionPerformed

    private void ventMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ventMenuItemActionPerformed
        // TODO add your handling code here:
        ventaHelado v2 = new ventaHelado();
        v2.setVisible(true); 

        this.addWindowListener(new java.awt.event.WindowAdapter() {
    @Override
    public void windowClosed(java.awt.event.WindowEvent e) {
        // liberar la referencia en el menú
        ventanaHelado = null;
    }
});

    }//GEN-LAST:event_ventMenuItemActionPerformed

    private void ventHistorialMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ventHistorialMenuItemActionPerformed
        // TODO add your handling code here:
        historialVenta h = new historialVenta();
        h.setVisible(true);
    }//GEN-LAST:event_ventHistorialMenuItemActionPerformed

    private void usuariosMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_usuariosMenuItemActionPerformed
        // TODO add your handling code here:
         historialVenta h = new historialVenta();
        h.setVisible(true);
    }//GEN-LAST:event_usuariosMenuItemActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(inicioMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(inicioMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(inicioMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(inicioMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new inicioMenu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu config;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenuBar jMenuBar2;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenu salirMenuItem;
    private javax.swing.JMenuItem usuariosMenuItem;
    private javax.swing.JMenuItem ventHistorialMenuItem;
    private javax.swing.JMenuItem ventMenuItem;
    private javax.swing.JMenu ventaMenu;
    // End of variables declaration//GEN-END:variables


}
