/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.puntoventahelados.Menu;

import com.mycompany.puntoventahelados.Menu.helado.pnlConoVaso;
import com.mycompany.puntoventahelados.Menu.helado.pnlFinalizar;
import com.mycompany.puntoventahelados.Menu.helado.pnlSabor;
import com.mycompany.puntoventahelados.Menu.helado.pnlTamanio;
import com.mycompany.puntoventahelados.Menu.helado.pnlToping;
import java.awt.CardLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author avero
 */
public class ventaHelado extends javax.swing.JFrame {
    private CardLayout cl;
    private JPanel contenedor;
    
    private pnlConoVaso panel1;
    private pnlTamanio panel2;
    private pnlSabor panel3;
    private pnlToping panel4;
    private pnlFinalizar panel5;
    
    private String tamanoSeleccionado;
    private String saborSeleccionado;
    private Double precioTemporal;

    public ventaHelado() {
        
        initComponents();
        setResizable(false);
        setSize(800, 600);
        setLocationRelativeTo(null);//centra el frame
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        cl = new CardLayout();
    contenedor = new JPanel(cl);

    // Cargar los JPanel diseñados en NetBeans
    pnlConoVaso panel1 = new pnlConoVaso(this);
    pnlTamanio panel2 = new pnlTamanio(this);
    pnlSabor panel3 = new pnlSabor(this);
    pnlToping panel4 = new pnlToping(this);
    pnlFinalizar panel5 = new pnlFinalizar(this);




    // Agregar al contenedor
    contenedor.add(panel1, "ConoVaso");
    contenedor.add(panel2, "Tamanio");
    contenedor.add(panel3, "Sabor");
    contenedor.add(panel4, "Toping");
    contenedor.add(panel5, "Finalizar");

    // Mostrar el contenedor en el JFrame
    setContentPane(contenedor);
    cl.first(contenedor); // muestra el primero agregado

    }

    public void mostrarSiguiente() {
    cl.next(contenedor); // pasa al siguiente panel en el CardLayout
}
    public void mostrarAnterior() {
    cl.previous(contenedor); // regresa al panel anterior
}
    public void mostrarPanel(String nombre) {
    cl.show(contenedor, nombre);
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocation(new java.awt.Point(0, 0));

        jPanel1.setMaximumSize(new java.awt.Dimension(1000, 1000));
        jPanel1.setPreferredSize(new java.awt.Dimension(704, 544));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 704, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 544, Short.MAX_VALUE)
        );

        jPanel2.setBackground(new java.awt.Color(204, 102, 255));
        jPanel2.setPreferredSize(new java.awt.Dimension(800, 600));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 800, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 600, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(368, 368, 368)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(89, 89, 89)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(15, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ventaHelado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ventaHelado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ventaHelado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ventaHelado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ventaHelado().setVisible(true);
            }
        });
    }
  
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
    public void setTamanoSeleccionado(String tamano) {
    this.tamanoSeleccionado = tamano;
    }

    public String getTamanoSeleccionado() {
    return tamanoSeleccionado;
    }

    public void setPrecioTemporal(double precio) {
    this.precioTemporal = precio;
    }

    public double getPrecioTemporal() {
    return precioTemporal;
    }
    

    public void setSaborSeleccionado(String s) { this.saborSeleccionado = s; }
    public String getSaborSeleccionado() { return saborSeleccionado; }

}
