/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.puntoventahelados.Menu.config;
import com.mycompany.puntoventahelados.Menu.config.Producto;


import java.util.List;

public class logica {
    public static double calcularPrecioBase(String tamanio) {
        return switch (tamanio.toLowerCase()) {
            case "chico" -> 20;
            case "mediano" -> 35;
            case "grande" -> 50;
            default -> 0;
        }; // por si acaso
}
    public static double calcularPrecioToppings(List<String> toppings) {
    if (toppings == null) return 0;
    int cantidad = toppings.size();
    if (cantidad <= 1) return 0;
    return (cantidad - 1) * 10;
}
    public static double calcularPrecioProducto(Producto p) {
        double base = calcularPrecioBase(p.getTamanio());
        double extra = calcularPrecioToppings(p.getToppings());
        return base + extra;
    }

    public static double calcularPrecioFinal(List<Producto> productos) {
    double total = 0;
    for (Producto p : productos) {
        total += calcularPrecioProducto(p);
    }
    return total;
}
}
