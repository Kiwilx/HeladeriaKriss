
package com.mycompany.puntoventahelados.Menu.config;

import java.util.List;
import java.util.ArrayList;

public class Producto {
    private String tipo;       // cono o vaso
    private String tamanio;    // chico, mediano, grande
    private String sabor;      // sabor elegido
    private List<String> toppings; // lista de toppings

    public Producto(String tipo, String tamanio, String sabor, List<String> toppings) {
        this.tipo = tipo;
        this.tamanio = tamanio;
        this.sabor = sabor;
        this.toppings = toppings;
    }
    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public String getTamanio() { return tamanio; }
    public void setTamanio(String tamanio) { this.tamanio = tamanio; }

    public String getSabor() { return sabor; }
    public void setSabor(String sabor) { this.sabor = sabor; }

    public List<String> getToppings() { return toppings; }
    public void setToppings(List<String> toppings) { this.toppings = toppings; }
    
   
}
